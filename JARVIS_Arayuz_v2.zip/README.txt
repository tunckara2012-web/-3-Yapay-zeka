JARVIS arayüz prototipi v2
- Mobil uyumlu koyu mavi/siyah arayüz ve çift halka ikon.
- İlk açılış kurulumu: Google bağlantısı adımı, Gemini API anahtarı adımı, ses açık/kapalı tercihi.
- Sohbet alanı boş başlar.
- Tarayıcı destekliyorsa mikrofon için Web Speech API, Türkçe sesli yanıt için speechSynthesis denenir.
- ÖNEMLİ: Google OAuth ve Gemini API henüz bağlanmış değildir. Google düğmesi açıkça bunu bildirir. API anahtarı yalnızca sayfa belleğinde tutulur ve yenilemede kaybolur; bu bir güvenli kasa değildir. Gerçek Gemini yanıtları için API entegrasyonu ve güvenlik tasarımı gerekir.
- Mevcut çalışan JARVIS projesinin üzerine koymadan önce kaynakları yedekleyin ve entegre edin.
