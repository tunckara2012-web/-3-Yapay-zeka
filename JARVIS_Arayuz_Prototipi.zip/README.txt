JARVIS arayüzü — sabit dosya adlarıyla güncellenmiş prototip

Dosyalar: index.html, jarvis-icon.svg, README.txt

İşlevler:
- Mevcut siyah/lacivert ve mavi-cyan çift halka arayüzü korunmuştur.
- İlk açılışta kurulum ekranı, Gemini API anahtarı ve ses tercihi sunulur.
- Ses açık seçilirse kurulum sonunda Türkçe karşılama seslendirilir; sessiz modda sesli yanıt verilmez.
- Gemini 2.5 Flash API'ye gerçek istek gönderir; API anahtarı tarayıcı localStorage alanında saklanır.
- Ayarlar düğmesi ve yan menüdeki Ayarlar üzerinden kurulum/ayar ekranı açılır.
- Tarayıcı destekliyorsa Web Speech API ile Türkçe mikrofon girişi denenir. Mikrofon izni ve HTTPS/localhost gerekebilir.
- Google Identity Services akışı eklenmiştir; gerçek Google girişi için Google Cloud Console'da OAuth Web istemci kimliği oluşturulmalı, doğru yetkili JavaScript kaynağı tanımlanmalı ve bu kimlik kurulum ekranına girilmelidir. Google girişi yalnızca istemci kimliği eklenmeden çalışmaz.

ÖNEMLİ GÜVENLİK NOTU:
Bu, yalnızca statik HTML/JavaScript prototipidir. Gemini anahtarını localStorage içinde tutmak güvenli bir kasa değildir; bu cihazdaki tarayıcı erişimi olan biri anahtarı okuyabilir. Gerçek, çok kullanıcılı yayına geçmeden önce kimlik doğrulamalı bir backend üzerinden anahtar yönetimi yapılması önerilir. Google kimlik doğrulama callback'i örnek düzeyindedir; uygulama hesabı/sunucu oturumu oluşturmaz. API anahtarını yalnızca güvendiğiniz cihazda kullanın.

Kullanım:
index.html dosyasını HTTPS üzerinden barındırın (ör. GitHub Pages). Mikrofon ve Google Identity Services bazı tarayıcı izinleri/HTTPS gerektirir. ZIP dosyasını GitHub'a doğrudan yüklemek web sitesini otomatik güncellemez; arşivi açıp içindeki dosyaları depodaki aynı adlı dosyalarla değiştirin.
