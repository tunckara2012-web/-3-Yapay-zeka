JARVIS arayüz prototipi

- index.html dosyasını tarayıcıda açarak arayüzü görebilirsin.
- jarvis-icon.svg, iç içe geçen iki mavi halkadan oluşan ikon taslağıdır.
- Mobil ve masaüstü ekranlara uyumlu olacak şekilde hazırlandı.
- Bu henüz arayüz prototipidir: Gemini API, gerçek mikrofon konuşma tanıma, Google girişi ve güvenli API anahtarı saklama bağlı değildir.
- Mevcut çalışan JARVIS projesinin üzerine uygulanmadan önce kaynak kodu incelenmelidir.
