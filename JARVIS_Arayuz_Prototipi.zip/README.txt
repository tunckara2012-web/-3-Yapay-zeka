JARVIS - güncellenmiş web prototipi

Dosyalar: index.html, jarvis-icon.svg

Kurulum:
1. ZIP dosyasını açın.
2. index.html ve jarvis-icon.svg dosyalarını GitHub Pages deposundaki aynı adlı dosyalarla değiştirin.
3. Değişikliklerin yayımlanmasını bekleyin. Telefonda Chrome'da siteyi açıp sayfayı yenileyin. Eski arayüz görünürse site verilerini/önbelleği temizleyin veya gizli sekmede deneyin.
4. İlk kurulumda Gemini API anahtarını girin. Model alanı Ayarlar'da düzenlenebilir; varsayılan model gemini-3.8-flash.
5. Sesli konuşmak için mikrofon düğmesine bir kez basın ve Chrome'un mikrofon iznini verin. Cümleyi bitirince JARVIS yanıtlar ve sesli mod açıkken yeniden dinlemeye döner. Durdur düğmesi dinlemeyi ve konuşmayı kapatır.

Notlar:
- Google/OAuth giriş ekranı bu sürümde yoktur.
- Tarayıcı konuşma tanıma özelliği Android Chrome ve site izinlerine bağlıdır; bu gerçek zamanlı Gemini Live bağlantısı değildir.
- API anahtarı tarayıcının yerel depolamasında tutulur. Herkese açık uygulama için güvenli bir kasa sayılmaz; anahtarı paylaşmayın.
- Gerçek API ve mikrofon cihaz üzerinde doğrulanmalıdır.
